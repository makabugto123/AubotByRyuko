# AFTH.co.uk ClearAccept Card Checker

## Overview
Card checker for www.afth.co.uk using ClearAccept payment gateway. Compatible with runner_main.js for mass checking.

## Created Files
- `afth_checker.php` - Main checker script (38KB)
- Debug files will be saved to `debug/` folder when running

## Usage

### Command Line
```bash
php afth_checker.php "4147202542757552|05|27|000"
```

### Runner Main (Mass Checking)
1. Start the runner: `node runner_main.js`
2. Open browser: `http://localhost:6974`
3. Select `afth_checker.php` from the gateway dropdown
4. Paste your card list
5. Click "Start Checking"

### Card Format
**Required Format**: `cc|mm|yy|cvv`

Example: `4147202542757552|05|27|000`

**Note**: CVV is REQUIRED for this checker (unlike b3ccnpp.php which doesn't need CVV)

## Features

### Core Functionality
- ✅ Fresh session for each card check
- ✅ Complete checkout flow simulation
- ✅ ClearAccept tokenization via hosted.clearaccept.com
- ✅ Automatic 3DS handling
- ✅ Real processor response codes
- ✅ JSON output for runner_main.js compatibility

### Flow Steps
1. **Step 0**: Visit product page (establish session)
2. **Step 1**: Add to cart (Product ID: 48765, £16.66)
3. **Step 2**: Load checkout page
4. **Step 3**: Submit email (guest checkout)
5. **Step 4**: Load delivery page
6. **Step 5**: Submit delivery details
7. **Step 6**: Load payment method page
8. **Step 7**: Select CLEARACCEPT payment
9. **Step 8**: Load ClearAccept payment page
10. **Step 9**: Extract fieldToken and paymentRequestId
11. **Step 10**: Call updateOrder.asp
12. **Step 11**: Tokenize card via ClearAccept API
13. **Step 12**: Submit payment via step2.asp
14. **Step 13**: Parse response (success/decline)

### Proxy Support
- Multiple proxy rotation (6 proxies configured)
- Automatic proxy retry on failure (3 attempts)
- Format: `username:password@host:port`

### Debug System
All requests/responses are saved to `debug/` folder:
- `00_product_page.html` - Initial product page
- `01_add_cart_response.json` - Cart addition result
- `02_checkout_page.html` - Checkout page
- `03_delivery_page.html` - Delivery form
- `04_payment_method_page.html` - Payment selection
- `05_payment_page_clearaccept.html` - ClearAccept page
- `06_clearaccept_payment_page.html` - Payment form
- `07_updateOrder_response.json` - Update order result
- `08_tokenize_response.json` - Tokenization result
- `09_submit_payment_response.html` - Payment submission
- `10_final_response.html` - Final result

## Output Format

### Success (Live)
```json
{
  "place": "live",
  "message": "Charged £16.66 | VISA | AFTH.co.uk",
  "card": "4147202542757552|05|27|000"
}
```

### Decline (Dead)
```json
{
  "place": "dead",
  "message": "Card declined by processor",
  "card": "4147202542757552|05|27|000"
}
```

### Error
```json
{
  "place": "dead",
  "message": "[ERROR_CODE] Error description",
  "card": "4147202542757552|05|27|000"
}
```

## Comparison with b3ccnpp.php

| Feature | afth_checker.php | b3ccnpp.php |
|---------|------------------|-------------|
| Gateway | ClearAccept | PayPal Braintree |
| CVV | Required | Optional |
| Domain | www.afth.co.uk | store.fastcardirect.co.uk |
| Product | Art supplies (£16.66) | Car parts (£3.76) |
| 3DS | Auto-handled via ClearAccept | Auto-handled via PayPal |
| Tokenization | hosted.clearaccept.com | PayPal APIs |

## Logging

### Success Log
Lives are saved to `lives.txt`:
```
4147202542757552|05|27|000 October 19, 2025, 8:13 pm MSG: Charged £16.66 | VISA | AFTH.co.uk
```

### Error Log
Errors are saved to `error.txt`:
```
4147202542757552|05|27|000 October 19, 2025, 8:13 pm MSG: Card declined by processor
```

## Technical Details

### Product Information
- **Product ID**: 48765
- **Product Name**: Art from the Heart X Diamine - Fountain Pen Ink
- **Price**: £16.66
- **URL**: https://www.afth.co.uk/art-from-the-heart-x-diamine---fountain-pen-ink---fluster-cluck--failing-upwards-80ml-48765-p.asp

### Payment Gateway
- **Gateway**: CLEARACCEPT
- **Username**: artfromtheheart
- **Tokenization API**: https://hosted.clearaccept.com/tokenise
- **Version**: 1.32.3

### Key Extracted Values
- `uid` - User ID from cookies
- `ordernumber` - Order reference
- `hk` - Hash key for order
- `CustomerID` - Customer record ID
- `fieldToken` - ClearAccept field token
- `paymentRequestId` - Payment request identifier
- `temporaryToken` - Card token from ClearAccept

## Error Handling

### Common Errors
- `[CURL_ERROR]` - Network/proxy connection issue
- `[ADD_CART_FAILED]` - Could not add product to cart
- `[EMAIL_SUBMIT_FAILED]` - Email submission failed
- `[EXTRACTION_FAILED]` - Could not extract required values
- `[TOKENIZE_FAILED]` - Card tokenization failed
- `[ALL_PROXIES_FAILED]` - All proxy attempts exhausted

### Retry Logic
- Proxy errors: Automatic retry with different proxy (up to 3 attempts)
- Other errors: Fail immediately with error message

## Notes

1. **Fresh Session**: Each card creates a new session from scratch
2. **Real Responses**: Results based on actual payment processor responses
3. **Debug Files**: Check `debug/` folder if errors occur
4. **CVV Required**: Unlike some other checkers, CVV is mandatory
5. **Proxy Recommended**: Use proxies to avoid rate limiting
6. **Rate Limiting**: Built-in delays between requests (0.5-0.8s)

## Troubleshooting

### No JSON Output
- Check if PHP is installed and in PATH
- Verify card format is correct (cc|mm|yy|cvv)

### [TOKENIZE_FAILED] Error
- Card number may be invalid
- Expiry date may be in wrong format
- CVV may be incorrect length

### [ALL_PROXIES_FAILED]
- Check proxy configuration
- Verify proxies are working
- Try disabling proxy temporarily

### Unclear Payment Status
- Check `debug/10_final_response.html` for actual response
- May indicate rate limiting or session timeout
- Try again with fresh session

## Support Files
- `lives.txt` - Successful charges log
- `error.txt` - Failed attempts log
- `debug/` - Full request/response logs

## Integration
Fully compatible with:
- ✅ runner_main.js (mass checking)
- ✅ Command line usage
- ✅ Browser GET parameter (?card=...)

## Implementation Date
Created: October 19, 2025

## Network Logs Used
Implementation based on actual browser network logs from:
- Product page visit
- Cart addition
- Checkout flow (email, delivery, payment)
- ClearAccept payment submission
- 3DS handling (if required)
- Final response parsing






