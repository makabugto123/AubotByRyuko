/**
 * Diagnostic script to identify why b3ccnpp.php is failing
 * Run with: node diagnose.js
 */

const { exec } = require('child_process');

console.log('='.repeat(70));
console.log('DIAGNOSTIC: Testing b3ccnpp.php Compatibility');
console.log('='.repeat(70));

// Test 1: Check if PHP is accessible
console.log('\n[TEST 1] Checking PHP installation...');
exec('php -v', (err, stdout, stderr) => {
    if (err) {
        console.log('❌ PHP NOT FOUND in system PATH');
        console.log('   Error:', err.message);
        console.log('\n💡 SOLUTION:');
        console.log('   You need to add PHP to your system PATH or use full path to php.exe');
        console.log('   Common PHP locations on Windows:');
        console.log('   - C:\\php\\php.exe');
        console.log('   - C:\\xampp\\php\\php.exe');
        console.log('   - C:\\wamp64\\bin\\php\\php8.x.x\\php.exe');
        console.log('   - C:\\laragon\\bin\\php\\php-8.x\\php.exe');
        
        // Try to find PHP in common locations
        console.log('\n[TEST 1.5] Searching for PHP in common locations...');
        const commonPaths = [
            'C:\\php\\php.exe',
            'C:\\xampp\\php\\php.exe',
            'C:\\wamp64\\bin\\php\\php8.2.0\\php.exe',
            'C:\\wamp64\\bin\\php\\php8.1.0\\php.exe',
            'C:\\wamp64\\bin\\php\\php8.0.0\\php.exe',
            'C:\\laragon\\bin\\php\\php-8.2\\php.exe',
            'C:\\laragon\\bin\\php\\php-8.1\\php.exe'
        ];
        
        const fs = require('fs');
        let foundPHP = false;
        
        for (const path of commonPaths) {
            if (fs.existsSync(path)) {
                console.log(`   ✓ Found PHP at: ${path}`);
                foundPHP = true;
                
                // Test this PHP installation
                console.log(`\n[TEST 2] Testing b3ccnpp.php with found PHP...`);
                testPHPScript(path);
                break;
            }
        }
        
        if (!foundPHP) {
            console.log('   ❌ PHP not found in common locations');
            console.log('\n   Please install PHP or provide the correct path');
        }
    } else {
        console.log('✓ PHP is installed');
        console.log('PHP Version:', stdout.split('\n')[0]);
        
        // Test the actual PHP script
        console.log('\n[TEST 2] Testing b3ccnpp.php output...');
        testPHPScript('php');
    }
});

function testPHPScript(phpPath) {
    const testCard = '4111111111111111|12|28';
    const command = `"${phpPath}" b3ccnpp.php "${testCard}"`;
    
    console.log(`Command: ${command}`);
    console.log('-'.repeat(70));
    
    exec(command, { maxBuffer: 1024 * 1024 * 10 }, (err, stdout, stderr) => {
        console.log('\n[RESULT] Raw output (first 500 chars):');
        console.log('-'.repeat(70));
        console.log(stdout.substring(0, 500));
        
        if (stdout.length > 500) {
            console.log(`\n... (${stdout.length} chars total)`);
        }
        
        console.log('-'.repeat(70));
        
        if (stderr) {
            console.log('\n[ERROR] PHP Errors/Warnings:');
            console.log(stderr);
        }
        
        console.log('\n[ANALYSIS] JSON Parse Test:');
        try {
            const result = JSON.parse(stdout);
            console.log('✅ Valid JSON output!');
            console.log('Structure:', JSON.stringify(result, null, 2));
            
            if (result.place && result.message && result.card) {
                console.log('\n✅ All required fields present');
                console.log('🎉 b3ccnpp.php is COMPATIBLE with runner_main.js');
            } else {
                console.log('\n❌ Missing required fields');
                console.log('Expected: place, message, card');
                console.log('Got:', Object.keys(result));
            }
        } catch (e) {
            console.log('❌ INVALID JSON OUTPUT');
            console.log('Parse Error:', e.message);
            console.log('\n💡 This is why you get "Processing Error - Invalid Response"');
            console.log('\n[DEBUG] Character analysis:');
            console.log('First char code:', stdout.charCodeAt(0));
            console.log('First char:', JSON.stringify(stdout[0]));
            console.log('Starts with {:', stdout.trimStart().startsWith('{'));
        }
        
        console.log('\n' + '='.repeat(70));
        console.log('DIAGNOSTIC COMPLETE');
        console.log('='.repeat(70));
    });
}

