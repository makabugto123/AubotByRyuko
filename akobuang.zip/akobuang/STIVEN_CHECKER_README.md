# Stiven.co.uk CyberSource Checker

Complete card checker for Stiven.co.uk using CyberSource Secure Acceptance payment processor.

## Features
- ✅ Full checkout flow automation
- ✅ AJAX basket management  
- ✅ CyberSource payment processing
- ✅ 3DS authentication (Cardinal Commerce)
- ✅ Proxy rotation with retry
- ✅ Debug logging to files
- ✅ Compatible with runner_main.js

## Usage

### Command Line
```bash
php stiven.php "4147097930561073|02|28|123"
```

### Browser
```
https://your-site.com/stiven.php?card=4147097930561073|02|28|123
```

### Mass Checking with runner_main.js
1. Start the server: `node runner_main.js`
2. Open browser: `http://localhost:6974`
3. Select `stiven.php` from gateway dropdown
4. Paste your cards
5. Click "Start Checking"

## Card Format
```
CARD_NUMBER|MONTH|YEAR|CVV
```
Example: `5370320118501876|06|28|000`

## Flow

1. **Visit Product Page** - Establish session
2. **Add to Cart** - POST to `/shop/addtobasket.php`
3. **Load Basket** - GET `/shop/checkout/basket.php`
4. **Get Basket Data** - AJAX GET `/shop/checkout/ajax.php?action=get_basket`
5. **Fill Customer Data** - Generate random UK customer info
6. **Submit Checkout** - AJAX POST with full basket object (`action=try_checkout`)
7. **Load Overview** - GET `/shop/checkout/basket_overview.php`
8. **Extract CyberSource Params** - Parse form inputs
9. **Get Signature** - POST to `/plugins/Cybersource/payment_confirmation.php`
10. **Submit to CyberSource** - POST to `https://secureacceptance.cybersource.com/embedded/pay`
11. **Load Payment Form** - POST to `/embedded/pay_load`
12. **Submit Card** - POST card details to `/embedded?sessionid=XXX`
13. **3DS Authentication** - POST to `/embedded/payer_authentication/hybrid`
14. **Get Final Result** - POST to `/embedded/pay_load` for result

## Output Format

### LIVE Card
```json
{
  "place": "live",
  "message": "Charged 10.39 GBP",
  "card": "4147097930561073|02|28|123"
}
```

### DEAD Card
```json
{
  "place": "dead",
  "message": "Payment declined",
  "card": "5370320118501876|06|28|000"
}
```

## Debug Files

All requests/responses saved to `debug/` folder:
- `00_product_page.html` - Initial product page
- `01_add_cart_response.json` - Cart add result
- `02_checkout_page.html` - Basket page
- `03_get_basket_response.json` - Basket data
- `04_try_checkout_response.json` - Checkout submit result
- `05_basket_overview.html` - Overview page with payment form
- `06_cybersource_initial.html` - CyberSource redirect
- `07.5_payment_confirmation.html` - Signature generation
- `07_payment_form.html` - Payment form
- `08_card_submit_response.html` - Card submission result
- `09_threeds_response.html` - 3DS authentication
- `10_final_result.html` - Final payment result

## Result Detection

The checker looks for these indicators:

**LIVE (Approved):**
- "charged"
- "payment accepted"
- "payment successful"  
- "transaction approved"
- "completed"

**DEAD (Declined):**
- "declined"
- "your order was declined"
- "error-banner"
- "has not been processed"
- "card provider has rejected"

## Configuration

### Proxy Settings
Edit the `$PROXY_LIST` array in `stiven.php`:
```php
$PROXY_LIST = [
    'user:pass@host:port',
    // Add more proxies
];
```

### Product Selection
Default product: Bird Brand Fast De-Icer (ID: 14401)

To change, edit:
```php
$product_id = 14401;
$product_url = 'https://www.stiven.co.uk/item/14401/...';
```

## Timing

Total execution time: ~8-12 seconds per card
- Each step: 0.2-0.5s delays
- Optimized for speed while avoiding session timeout

## Error Handling

- Automatic proxy rotation (max 3 attempts)
- Session timeout detection
- CURL error handling
- Form validation errors
- CyberSource parameter extraction failures

## Logs

- `lives.txt` - Successful charges
- `error.txt` - Declined/failed cards

## Notes

### Important Limitations

1. **JavaScript PostMessage**: The site uses iframe postMessage for final status. Since PHP can't execute JavaScript, result detection is based on HTML content analysis.

2. **Session Timing**: CyberSource sessions timeout after ~15 minutes of inactivity. Script is optimized for speed.

3. **3DS Handling**: 3DS authentication is attempted but may not be fully functional in headless mode. The script handles the endpoints but cannot interact with 3DS challenges.

### Recommendations

- Test with known good/bad cards first
- Check `debug/` folder if results are unclear
- Monitor `error.txt` for specific decline reasons
- Use proxies to avoid rate limiting

## Troubleshooting

**"Payment status unclear"**
- Check `debug/10_final_result.html` for actual response
- May need to refine result detection based on actual responses

**"Session timeout"**
- Script running too slow (unlikely with current delays)
- Try disabling proxy: Set `$PROXY` to empty string

**"Basket redirected"**
- Checkout validation failed
- Check `debug/04_try_checkout_response.json`

## Compatibility

- PHP 7.0+
- cURL with proxy support
- Works with runner_main.js v1.0+

## Support

For issues, check debug files in order and identify where the flow breaks.





