import re

input_file = "input.txt"
output_file = "final.txt"

# Read input file
with open(input_file, "r", encoding="utf8") as f:
    data = f.read().strip()

# Stop if empty
if not data:
    print("input.txt is empty")
    exit()

# Remove timestamp patterns like [31/10/2025 12:05 am]
data = re.sub(r"\[[^\]]*\]\s*", "", data)

# Split on newline OR multiple spaces
records = re.split(r"[ \n]+", data)

output = []

for rec in records:
    # Split into fields
    fields = rec.split("|")
    
    # Only save if record has at least 4 fields
    if len(fields) >= 4:
        # Keep the first 4 fields only
        cleaned = "|".join(fields[:4])
        
        # Add ONLY if first field is not text (prevents addresses)
        if cleaned.replace("|", "").isdigit():  
            output.append(cleaned)

# Save output
with open(output_file, "w", encoding="utf8") as f:
    f.write("\n".join(output))

print("Saved to final.txt")
